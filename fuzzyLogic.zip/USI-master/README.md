# USI - Układy Sterowania Inteligentnego 

## Opis folderów:
**MATLAB** - wszystkie pliki z Matlaba

**sprawozdanie** 
* /spr.tex - główny plik w którym includowane są poszczególne rodziały,
* /bib.tex - bibliografia jeżeli będzie potrzebna,
* /lab1, /lab2 - kolejne rodziały,
* /fig - folder z wykesami, rysunkami zawartymi w sprawozdaniu. 
