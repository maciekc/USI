syms z u1 u2 B1 B2 K1 K2

